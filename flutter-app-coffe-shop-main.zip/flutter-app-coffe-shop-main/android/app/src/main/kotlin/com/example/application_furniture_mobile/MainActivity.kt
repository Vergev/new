package com.application_coffe_shop_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
